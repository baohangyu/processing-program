#ifndef _RUN_H_
#define _RUN_H_
	
	#include "common.h"
	
	#define	CH_COUNT	2	//ʹ��ͨ����

	extern uchar curData;
	extern uchar ch[CH_COUNT];
	extern uchar chIndex;
	extern uchar info[8];
	

	void sendData(uchar dat);

	

#endif
