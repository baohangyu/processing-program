#ifndef _DELAY_H_
#define	_DELAY_H_

	void delayMS(unsigned int MS);


#endif