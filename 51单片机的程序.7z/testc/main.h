#ifndef _MAIN_H_
#define _MAIN_H_

	#include "common.h"
	#include "delay.h"
	#include "init.h"

	#include "interrupt.h"

	void sendDate(uchar dat);
#endif