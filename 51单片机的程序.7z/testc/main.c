#include "main.h"

void main(){
	int i=0;
	sysInit();
	while(1);
}