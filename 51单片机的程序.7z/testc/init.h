#ifndef _INIT_H_
#define _INIT_H_

	#include "common.h"
	#include "delay.h"
	#include "run.h"


	
	void iniCPU(void);
	void sysInit(void);

   	
#endif