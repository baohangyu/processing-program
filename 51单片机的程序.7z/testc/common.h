#ifndef _COMMON_H_
#define	_COMMON_H_
	#include <intrins.H>
	#include "stc.h"
	#define uchar unsigned char
	#define uint  unsigned int
	#define ulong unsigned long

	#define Wait1us {_nop_();}
	#define Wait2us {Wait1us;Wait1us;}
	#define Wait4us {Wait2us;Wait2us;}
	#define Wait8us {Wait4us;Wait4us;}
	#define Wait10us {Wait8us;Wait2us;}
	#define Wait36us {Wait8us;Wait8us;Wait8us;Wait8us;Wait4us;}
	#define Wait100us {Wait36us;Wait36us;Wait10us;Wait10us;Wait8us}


		
	//ADC����
	#define		ADC_FLAG	0x10
	#define		ADC_POWER	0x80
	#define		ADC_START	0x08
	#define		ADC_SPEEDLL	0x00
	#define		ADC_SPEEDL	0x20
	#define		ADC_SPEEDH	0x40
	#define		ADC_SPEEDHH	0x60


	sbit key1=P1^2;
	sbit key2=P1^3;
	sbit key3=P1^4;

	sbit led=P2^2;
	sbit bState=P2^5;	//����״̬

	//Vr��18��ADC0	P1.0
	//V0��23��ADC5	P1.5


	//���ֽں�˫�ֽڹ�����
	union intAndTwoChar{
		unsigned int setInt;
	    unsigned int getInt;
		unsigned char setChar[2];	    
		unsigned char getChar[2];
	};
	//���ֽں͵��ֽڹ�����
	union longIntChar{
		unsigned long setLong;
	    unsigned long getLong;
		unsigned int setInt[2];
	    unsigned int getInt[2];
		unsigned char setChar[4];	    
		unsigned char getChar[4];
	};

#endif